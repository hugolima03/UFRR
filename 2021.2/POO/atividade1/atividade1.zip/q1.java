class q1 {
  public static void main(String[] args) {
    int i;
    for (i = 150; i<301; i++) {
      System.out.println(i);
    }
  }
}