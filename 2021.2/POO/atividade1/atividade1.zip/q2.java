class q2 {
  public static void main(String[] args) {
    int i;
    int c = 0;
    for (i = 0; i < 1001; i++) {
      c = c + i;
    }
    System.out.println(c);
  }
}