public class Schedule {
  String time;
  String day;
  String subject;

  public Schedule(String time, String day, String subject) {
    this.time = time;
    this.day = day;
    this.subject = subject;
  }
}
